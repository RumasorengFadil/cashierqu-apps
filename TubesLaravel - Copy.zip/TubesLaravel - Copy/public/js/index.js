const header = document.querySelector(".homepage");
window.addEventListener("resize",function(){
    header.style.height = window.innerHeight + "px";
})
window.addEventListener("load",function(){
    header.style.height = window.innerHeight + "px";
})
