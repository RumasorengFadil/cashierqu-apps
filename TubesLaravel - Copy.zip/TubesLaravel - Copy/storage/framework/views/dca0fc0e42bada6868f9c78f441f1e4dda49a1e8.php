<nav class="nav">
    <div class="nav__items">
        <nav class="nav__item">
            <a href="/goods"><img class="nav__icon" src=<?php echo e($_SERVER['REQUEST_URI'] === "/goods" ? "assets/icons/goods--fill.svg" : "assets/icons/goods--outline.svg"); ?> alt=""></a>
        </nav>
        <nav class="nav__item">
            <a href="/order"><img class="nav__icon" src=<?php echo e($_SERVER['REQUEST_URI'] === "/order" ? "assets/icons/order--fill.svg" : "assets/icons/order--outline.svg"); ?> alt=""></a>
        </nav>
        <nav class="nav__item">
            <a href="/history"><img class="nav__icon" src=<?php echo e($_SERVER['REQUEST_URI'] === "/history" ? "assets/icons/history--fill.svg" : "assets/icons/history--outline.svg"); ?> alt=""></a>
        </nav>
        <nav class="nav__item">
            <a href="/settings"><img class="nav__icon" src=<?php echo e($_SERVER['REQUEST_URI'] === "/settings" ? "assets/icons/settings--fill.svg" : "assets/icons/settings--outline.svg"); ?> alt=""></a>
        </nav>
        <nav class="nav__item">
            <a href="/"><img class="nav__icon" src="<?php echo e(asset("assets/icons/logout--outline.svg")); ?>" alt=""></a>
        </nav>
    </div>
</nav><?php /**PATH C:\Users\Acer SPIN\OneDrive\Desktop\Fadil\Kuliah\Semester\Semester 3\Web\TubesLaravel\resources\views//fragments/nav.blade.php ENDPATH**/ ?>