<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset("css/index.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/form.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/order.css")); ?>">
    <link rel="shortcut icon" type="image/svg" href="/assets/icons/succes.svg">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="col-2">
            <div class="cart">  
                <h1 class="form__title"><span class="form__title--blue">Shopping</span> Cart</h1>
                <div class="tb-cn tb-cn-shopping-cart">
                    <table class="tb">
                        <thead class="tb__head">
                            <tr>
                                <th>Nama barang</th>
                                <th>Quantity</th>
                                <th>Harga barang</th>
                                <th>Discount</th>
                            </tr>
                        </thead>
                        <tbody class="tb__body">
                            <tr class="tb__row--odd">
                                <td class="tb__data">0001</td>
                                <td class="tb__data">Shampo</td>
                                <td class="tb__data">15000</td>
                                <td class="tb__data">57</td>
                            </tr>
                            <tr class="tb__row--even">
                                <td class="tb__data">0001</td>
                                <td class="tb__data">Shampo</td>
                                <td class="tb__data">15000</td>
                                <td class="tb__data">57</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="form-cn form-cn-add-to-cart">
                    <form action="" class="form">
                        <div class="form__elemen">
                            <label class="form__label" for="username">Nama Barang</label><br>
                            <input class="form__input" type="text" name="inputNamaBarang" id="inputNamaBarang" required>
                            <ul class="items-goods hidden">
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                            </ul>   
                        </div>
                        <div class="form__elemen">
                            <label class="form__label" for="username">Quantity</label><br>
                            <input class="form__input" type="text" name="inputHargaBarang" id="inputHargaBarang" required>
                        </div>
                        <div class="form__elemen">
                            <input class="form__submit" type="submit" name="inputJudul" id="inputJudul" value="Add to chart"> <!--! from index-->
                        </div>
                    </form>
                </div>

                <div class="payment-info">
                    <ul class="li-items">
                        <li class="li-item li-item-subtotal">
                            <p class=li-item__text>Subtotal</p>
                            <p class="li-item__nom-subtotal">Rp.10000</p>
                        </li>
                        <li class="li-item li-item-disc">
                            <p class=li-item__text>Discount</p>
                            <p class="li-item__nom-disc">Rp.10000</p>
                        </li>
                        <li class="li-item li-item-nom-bayar">
                            <p class=li-item__text>Nominal bayar</p>
                            <p class="li-item__nom-bayar">Rp.10000</p>
                        </li>
                        <li class="li-item li-item-total">
                            <p class=li-item__text>Total</p>
                            <p class="li-item__nom-total">Rp.10000</p>
                        </li>
                        <li class="li-item li-item-kembalian">
                            <p class=li-item__text>Kembalian</p>
                            <p class="li-item__nom-kembalian">Rp.10000</p>
                        </li>      
                    </ul>
                    <button class="form__submit form__submit-pay-info">Proceed</button>
                </div> 
            </div>

            <div class="list-goods hidden">
                <div class="tb-cn tb-cn-list-goods">
                    <h1 class="form__title"><span class="form__title--blue">Daftar</span> Barang</h1>
                    <table class="tb">
                        <thead class="tb__head">
                            <tr>
                                <th>Id barang</th>
                                <th>Nama barang</th>
                                <th>Harga barang</th>
                                <th>Stok barang</th>
                                <th>Discount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="tb__body">
                            <tr class="tb__row--odd">
                                <td class="tb__data">0001</td>
                                <td class="tb__data">Shampo</td>
                                <td class="tb__data">15000</td>
                                <td class="tb__data">57</td>
                                <td class="tb__data">10000</td>
                                <td class="tb__data tb__data-actions">
                                    <img class="tb__icn tb__icn-edit" src="/src/app/assets/icons/edit.svg" alt="">
                                    <img class="tb__icn tb__icn-trash" src="/src/app/assets/icons/trash.svg" alt="">
                                </td>
                            </tr>
                            <tr class="tb__row--even">
                                <td class="tb__data">0001</td>
                                <td class="tb__data">Shampo</td>
                                <td class="tb__data">15000</td>
                                <td class="tb__data">57</td>
                                <td class="tb__data">10000</td>
                                <td class="tb__data tb__data-actions">
                                    <img class="tb__icn tb__icn-edit" src="/src/app/assets/icons/edit.svg" alt="">
                                    <img class="tb__icn tb__icn-trash" src="/src/app/assets/icons/trash.svg" alt="">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="form-cn-search">
                    <h1 class="form__title form__title-search">Cari Barang</h1>
                    <form class="form form-search" action="form" id="form">
                        <div class="form__elemen form__elemen-search">
                            <input class="form__input form__input-search" type="search" name="inputSearch" id="inputNamaSupermarket" required>
                        </div>
                        <div class="form__elemen form__elemen-search">
                            <input class="form__submit form__submit-search" type="submit" name="inputJudul" id="inputJudul" value="Search">   
                        </div>
                    </form>
                </div>
                <div class="form-cn">
                    <form action="" class="form">
                        <div class="form__elemen">
                            <label class="form__label" for="username">Nama Barang</label><br>
                            <input class="form__input" type="text" name="inputNamaBarang" id="inputNamaBarang" required>
                            <ul class="items-goods hidden">
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                                <li class="item-goods">test</li>
                            </ul>   
                        </div>
                        <div class="form__elemen">
                            <label class="form__label" for="username">Quantity</label><br>
                            <input class="form__input" type="text" name="inputHargaBarang" id="inputHargaBarang" required>
                        </div>
                        <div class="form__elemen">
                            <input class="form__submit" type="submit" name="inputJudul" id="inputJudul" value="Add to chart"> <!--! from index-->
                        </div>
                    </
            </div>
        </div>
        </div>


        <nav class="nav">
            <div class="nav__items">
                <nav class="nav__item">
                    <a href=""><img class="nav__icon" src="<?php echo e(asset("assets/icons/order--fill.svg")); ?>" alt=""></a>
                </nav>
                <nav class="nav__item">
                    <a href="/cashierHistory"><img class="nav__icon" src="<?php echo e(asset("assets/icons/history--outline.svg")); ?>" alt=""></a>
                </nav>
                <nav class="nav__item">
                    <a href="http://127.0.0.1:8000/"><img class="nav__icon" src="<?php echo e(asset("assets/icons/logout--outline.svg")); ?>" alt=""></a>
                </nav>
            </div>
        </nav>
    </div>
        
</body>
</html><?php /**PATH C:\Users\Acer SPIN\OneDrive\Desktop\Fadil\Kuliah\Semester\Semester 3\Web\TubesLaravel\resources\views/order.blade.php ENDPATH**/ ?>