<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset("css/index.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/history.css")); ?>">
    <title>Cashierqu</title>
    <title>Document</title>
</head>
<body>
    <h1 class="title"><span class="title--blue">History</span> Pembelian</h1>
    <div class="container">
        <div class="tb-cn">
            <table class="tb">
                <thead class="tb__head">
                    <tr>
                        <th>Id transaksi</th>
                        <th>Id barang</th>
                        <th>Id kasir</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody class="tb__body">
                    <tr class="tb__row--odd">
                        <td class="tb__data">0001</td>
                        <td class="tb__data">0001</td>
                        <td class="tb__data">0001</td>
                        <td class="tb__data">235</td>
                        <td class="tb__data">15000</td>
                        <td class="tb__data">21 january</td>
                    </tr>
                    <tr class="tb__row--even">
                        <td class="tb__data">0001</td>
                        <td class="tb__data">0001</td>
                        <td class="tb__data">0001</td>
                        <td class="tb__data">235</td>
                        <td class="tb__data">15000</td>
                        <td class="tb__data">21 january</td>
                    </tr>
    
                </tbody>
            </table>
        </div>
        <nav class="nav">
            <div class="nav__items">
                <nav class="nav__item">
                    <a href="http://127.0.0.1:8000/goods"><img class="nav__icon" src="<?php echo e(asset("assets/icons/order--outline.svg")); ?>" alt=""></a>
                </nav>
                <nav class="nav__item">
                    <a href=""><img class="nav__icon" src="<?php echo e(asset("assets/icons/history--fill.svg")); ?>" alt=""></a>
                </nav>
                <nav class="nav__item">
                    <a href="http://127.0.0.1:8000/"><img class="nav__icon" src="<?php echo e(asset("assets/icons/logout--outline.svg")); ?>" alt=""></a>
                </nav>
            </div>
        </nav>
    </div>
    
</body>
</html><?php /**PATH C:\Users\Acer SPIN\OneDrive\Desktop\Fadil\Kuliah\Semester\Semester 3\Web\TubesLaravel\resources\views/cashierHistory.blade.php ENDPATH**/ ?>