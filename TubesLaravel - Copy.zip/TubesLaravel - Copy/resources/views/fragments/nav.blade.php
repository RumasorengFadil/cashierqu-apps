<nav class="nav">
    <div class="nav__items">
        @yield('navItem')
    </div>
</nav>